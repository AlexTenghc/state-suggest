<template>
  <div>
    <input type="text" v-model="query" @input="fetchStates" placeholder="Search for a state" />
    <ul v-if="states.length">
      <li v-for="state in states" :key="state.name" @click="selectState(state.name)">{{ state.name }}</li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'StateTypeahead',
  data() {
    return {
      query: '',
      states: [],
    };
  },
  methods: {
    async fetchStates() {
      if (this.query.length > 1) {
        const response = await axios.post('http://localhost:8080/graphql', {
          query: `
            query($search: String) {
              states(search: $search) {
                name
              }
            }
          `,
          variables: { search: this.query },
        });
        this.states = response.data.data.states;
      } else {
        this.states = [];
      }
    },
    selectState(state) {
      this.$emit('stateSelected', state);
      this.query = state;
      this.states = [];
    },
  },
};
</script>
