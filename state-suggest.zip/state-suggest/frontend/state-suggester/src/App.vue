<template>
  <div id="app">
    <StateTypeahead @stateSelected="stateSelected" />
    <StateMap :selectedState="selectedState" />
  </div>
</template>

<script>
import StateTypeahead from './components/StateTypeahead.vue';
import StateMap from './components/StateMap.vue';

export default {
  data() {
    return {
      selectedState: null,
    };
  },
  components: {
    StateTypeahead,
    StateMap,
  },
  methods: {
    stateSelected(state) {
      this.selectedState = state;
    },
  },
};
</script>
